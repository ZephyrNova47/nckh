"use client"

import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { GraduationCap, Users, Sparkles, Heart, Crown, Award } from "lucide-react"
import Image from "next/image"

const principalInvestigator = {
  name: "Assoc. Prof. Vo Dinh Hieu",
  role: "Principal Investigator",
  affiliation: "VNU-UET",
  image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Vo%20Dinh%20Hieu-9xPSCQb2sRuMFWJHlYzX9CZT00U3oQ.jpg",
}

const supervisors = [
  {
    name: "Dr. Nguyen Thu Trang",
    role: "Supervisor",
    affiliation: "VNU-UET",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Nguyen%20Thu%20Trang-4iKGQBFuJN8R7rOdXs7i3DSnbPqv4a.jpg",
  },
  {
    name: "Dr. Nguyen Van Son",
    role: "Supervisor",
    affiliation: "VNU-UET",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Nguyen%20Van%20Son-sN2KD8op9d7BjIppnvEqp3JQbjnqoQ.jpg",
  },
]

const students = [
  {
    name: "Lam Nguyen Duy Phong",
    class: "QH-2022-CS1",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Lam%20Nguyen%20Duy%20Phong-4HHWlxPJVgjASnHDUoRoorxtyQv9K7.jpg",
  },
  {
    name: "Nguyen Ha Linh",
    class: "QH-2022-IS",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Nguyen%20Ha%20Linh-tTMZTwVlkwlj0m7TlTk9JQPvOxW729.jpg",
  },
  {
    name: "Dang Dao Xuan Truc",
    class: "QH-2022-CS1",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Dang%20Dao%20Xuan%20Truc-lUCS9ulprWLYOc5BFzWbYLAMrDaIE8.jpg",
  },
  {
    name: "Nguyen Hong Anh",
    class: "QH-2023-CS4",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Nguyen%20Hong%20Anh-VsunewSOjT4yGkV4cBOhMhuG8J8gvV.jpg",
  },
  {
    name: "La Minh Duc",
    class: "QH-2023-IS",
    image: "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/La%20Minh%20Duc-OWCbLuteq36Xx1LcSAKAjpG9qiXjLl.jpg",
  },
]

export function TeamSection() {
  return (
    <section id="team" className="py-16 md:py-24 bg-muted/30 relative overflow-hidden">
      {/* Cute decorations */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 right-10 w-4 h-4 bg-primary/30 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
        <div className="absolute bottom-40 left-20 w-3 h-3 bg-secondary/40 rounded-full animate-bounce" style={{ animationDelay: '0.7s' }} />
        <div className="absolute top-1/2 left-10 w-2 h-2 bg-accent/40 rounded-full animate-bounce" style={{ animationDelay: '1.4s' }} />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 rounded-full px-4 py-1.5 border-2 border-secondary">
            <Sparkles className="h-3.5 w-3.5 mr-1.5" />
            Research Team
            <Sparkles className="h-3.5 w-3.5 ml-1.5" />
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
            Meet Our Team
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-balance">
            A dedicated group of researchers from the Faculty of Information Technology 
            and the Intelligent Software Engineering (iSE) Laboratory.
          </p>
        </div>

        {/* Tier 1: Principal Investigator */}
        <div className="mb-14">
          <div className="flex items-center justify-center gap-2 mb-8">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-600 via-orange-500 to-amber-400 flex items-center justify-center shadow-lg shadow-orange-500/30">
              <Award className="h-5 w-5 text-white" />
            </div>
            <h3 className="text-xl font-bold text-foreground">Principal Investigator</h3>
          </div>
          <div className="flex justify-center">
            <Card className="max-w-sm border-2 border-orange-300/50 hover:shadow-2xl transition-all duration-300 group overflow-hidden bg-gradient-to-br from-card to-orange-50">
              <div className="absolute top-0 right-0 w-24 h-24 bg-gradient-to-br from-amber-500 to-orange-400 opacity-10 rounded-bl-full" />
              <CardContent className="pt-8 pb-6 text-center relative">
                <div className="relative w-32 h-32 mx-auto mb-4">
                  <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-amber-600 via-orange-500 to-amber-400 p-1 shadow-xl">
                    <div className="w-full h-full rounded-xl overflow-hidden">
                      <Image
                        src={principalInvestigator.image}
                        alt={principalInvestigator.name}
                        width={128}
                        height={128}
                        className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                    </div>
                  </div>
                  <div className="absolute -top-2 -right-2 w-8 h-8 bg-gradient-to-br from-amber-400 to-orange-500 rounded-full flex items-center justify-center shadow-lg">
                    <Crown className="h-4 w-4 text-white" />
                  </div>
                </div>
                <h4 className="font-bold text-foreground text-lg mb-2">{principalInvestigator.name}</h4>
                <Badge className="rounded-full mb-2 bg-gradient-to-r from-amber-600 via-orange-500 to-amber-400 border-0 text-white">
                  <Award className="h-3 w-3 mr-1" />
                  {principalInvestigator.role}
                </Badge>
                <p className="text-sm text-muted-foreground">{principalInvestigator.affiliation}</p>
              </CardContent>
            </Card>
          </div>
        </div>

        {/* Tier 2: Supervisors */}
        <div className="mb-14">
          <div className="flex items-center justify-center gap-2 mb-8">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-orange-400 to-amber-500 flex items-center justify-center shadow-lg">
              <GraduationCap className="h-5 w-5 text-white" />
            </div>
            <h3 className="text-xl font-bold text-foreground">Supervisors</h3>
          </div>
          <div className="flex flex-wrap justify-center gap-6 max-w-2xl mx-auto">
            {supervisors.map((supervisor, index) => (
              <Card key={index} className="flex-1 min-w-[220px] max-w-[280px] border-2 border-transparent hover:border-orange-300/40 hover:shadow-2xl transition-all duration-300 group overflow-hidden">
                <div className="absolute top-0 right-0 w-20 h-20 bg-gradient-to-br from-orange-400 to-yellow-400 opacity-10 rounded-bl-full" />
                <CardContent className="pt-8 pb-6 text-center relative">
                  <div className="relative w-28 h-28 mx-auto mb-4">
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-orange-500 via-amber-500 to-yellow-400 p-1 shadow-lg">
                      <div className="w-full h-full rounded-xl overflow-hidden">
                        <Image
                          src={supervisor.image}
                          alt={supervisor.name}
                          width={112}
                          height={112}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                    </div>
                  </div>
                  <h4 className="font-bold text-foreground text-base mb-2">{supervisor.name}</h4>
                  <Badge variant="secondary" className="rounded-full mb-2">
                    <GraduationCap className="h-3 w-3 mr-1" />
                    {supervisor.role}
                  </Badge>
                  <p className="text-sm text-muted-foreground">{supervisor.affiliation}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Tier 3: Students */}
        <div>
          <div className="flex items-center justify-center gap-2 mb-8">
            <div className="w-10 h-10 rounded-full bg-gradient-to-br from-amber-400 to-yellow-500 flex items-center justify-center shadow-lg">
              <Users className="h-5 w-5 text-white" />
            </div>
            <h3 className="text-xl font-bold text-foreground">Student Researchers</h3>
          </div>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4 max-w-5xl mx-auto">
            {students.map((student, index) => (
              <Card key={index} className="border-2 border-transparent hover:border-primary/20 hover:shadow-xl transition-all duration-300 group overflow-hidden">
                <CardContent className="pt-6 pb-4 text-center relative">
                  <div className="relative w-20 h-20 mx-auto mb-3">
                    <div className="absolute inset-0 rounded-2xl bg-gradient-to-br from-amber-400 to-yellow-500 p-0.5 shadow-lg group-hover:scale-105 group-hover:rotate-2 transition-all duration-300">
                      <div className="w-full h-full rounded-2xl overflow-hidden">
                        <Image
                          src={student.image}
                          alt={student.name}
                          width={80}
                          height={80}
                          className="w-full h-full object-cover"
                        />
                      </div>
                    </div>
                  </div>
                  <h4 className="font-semibold text-foreground text-sm mb-1 min-h-[2.5rem] flex items-center justify-center text-balance">{student.name}</h4>
                  <p className="text-xs text-muted-foreground">{student.class}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>

        {/* Lab Acknowledgment - Cute Style */}
        <div className="mt-14 text-center">
          <Card className="inline-block border-2 border-primary/20 shadow-xl overflow-hidden">
            <CardContent className="pt-6 px-10 pb-6 relative">
              <div className="absolute top-0 right-0 w-16 h-16 bg-primary/10 rounded-bl-full" />
              <div className="absolute bottom-0 left-0 w-12 h-12 bg-secondary/20 rounded-tr-full" />
              
              <div className="flex items-center justify-center gap-2 mb-3">
                <Heart className="h-5 w-5 text-primary animate-pulse" />
                <p className="text-sm text-muted-foreground font-medium">Affiliated with</p>
                <Heart className="h-5 w-5 text-primary animate-pulse" />
              </div>
              <p className="font-bold text-foreground text-lg">
                Intelligent Software Engineering (iSE) Laboratory
              </p>
              <p className="text-sm text-muted-foreground">
                Faculty of Information Technology, VNU-UET
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  )
}
