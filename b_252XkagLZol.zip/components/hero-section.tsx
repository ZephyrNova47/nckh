import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { ArrowRight, FileText, Sparkles, Star, Heart } from "lucide-react"

export function HeroSection() {
  return (
    <section className="relative pt-24 pb-16 md:pt-32 md:pb-24 overflow-hidden">
      {/* Cute decorative elements */}
      <div className="absolute inset-0 -z-10 overflow-hidden">
        <div className="absolute top-20 left-10 w-4 h-4 bg-primary/40 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
        <div className="absolute top-32 right-20 w-3 h-3 bg-secondary/60 rounded-full animate-bounce" style={{ animationDelay: '0.5s' }} />
        <div className="absolute top-40 left-1/4 w-2 h-2 bg-accent/50 rounded-full animate-bounce" style={{ animationDelay: '1s' }} />
        <div className="absolute bottom-40 right-1/3 w-3 h-3 bg-primary/30 rounded-full animate-bounce" style={{ animationDelay: '1.5s' }} />
        <div className="absolute top-1/2 right-10 w-2 h-2 bg-secondary/50 rounded-full animate-bounce" style={{ animationDelay: '2s' }} />
        
        {/* Soft blob backgrounds */}
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-primary/10 rounded-full blur-3xl -translate-y-1/2 translate-x-1/4" />
        <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-secondary/20 rounded-full blur-3xl translate-y-1/2 -translate-x-1/4" />
        <div className="absolute top-1/2 left-1/2 w-[300px] h-[300px] bg-accent/10 rounded-full blur-3xl -translate-x-1/2 -translate-y-1/2" />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="max-w-4xl mx-auto text-center">
          {/* Cute Badge */}
          <Badge variant="secondary" className="mb-6 px-5 py-2 text-sm font-medium rounded-full border-2 border-secondary shadow-lg shadow-secondary/20">
            <Star className="h-3.5 w-3.5 mr-1.5 text-secondary-foreground" />
            VNU-UET Research 2025-2026
            <Sparkles className="h-3.5 w-3.5 ml-1.5 text-secondary-foreground" />
          </Badge>

          {/* Title with cute styling */}
          <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold tracking-tight text-foreground mb-6 text-balance">
            <span className="relative inline-block">
              <span className="text-orange-600">Coca</span>
              <Heart className="absolute -top-2 -right-6 h-5 w-5 text-orange-400 animate-pulse" />
            </span>
            {" "}
            <span className="bg-clip-text text-transparent bg-gradient-to-r from-foreground via-amber-600 to-orange-500">
              Automated Weak Supervision
            </span>
          </h1>

          {/* Subtitle */}
          <p className="text-xl md:text-2xl text-muted-foreground mb-4 font-medium">
            From Unlabeled Data to High-Quality Datasets
          </p>

          {/* Description with cute card */}
          <div className="relative inline-block mb-8">
            <div className="absolute inset-0 bg-primary/5 rounded-3xl blur-xl" />
            <p className="relative text-base md:text-lg text-muted-foreground max-w-2xl mx-auto leading-relaxed px-6 py-4 bg-card/50 rounded-3xl border-2 border-primary/10">
              A fully automated framework that transforms unlabeled data into both high-quality labeled datasets 
              and robust classifiers through principled label function generation.
            </p>
          </div>

          {/* Cute Stats Cards */}
          <div className="flex flex-wrap justify-center gap-4 mb-10">
            <div className="group relative px-6 py-4 bg-card rounded-3xl border-2 border-orange-300/40 shadow-lg shadow-orange-500/10 hover:shadow-xl hover:shadow-orange-500/20 hover:scale-105 transition-all duration-300">
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-br from-amber-500 to-orange-500 rounded-full flex items-center justify-center">
                <Sparkles className="h-3 w-3 text-white" />
              </div>
              <div className="text-3xl md:text-4xl font-bold text-orange-600">98.9%</div>
              <div className="text-sm text-muted-foreground">Label Coverage</div>
            </div>
            <div className="group relative px-6 py-4 bg-card rounded-3xl border-2 border-amber-300/40 shadow-lg shadow-amber-500/10 hover:shadow-xl hover:shadow-amber-500/20 hover:scale-105 transition-all duration-300">
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-br from-amber-400 to-yellow-500 rounded-full flex items-center justify-center">
                <Star className="h-3 w-3 text-white" />
              </div>
              <div className="text-3xl md:text-4xl font-bold text-amber-600">+138%</div>
              <div className="text-sm text-muted-foreground">Quality Boost</div>
            </div>
            <div className="group relative px-6 py-4 bg-card rounded-3xl border-2 border-yellow-300/40 shadow-lg shadow-yellow-500/10 hover:shadow-xl hover:shadow-yellow-500/20 hover:scale-105 transition-all duration-300">
              <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-br from-yellow-400 to-amber-400 rounded-full flex items-center justify-center">
                <Heart className="h-3 w-3 text-white" />
              </div>
              <div className="text-3xl md:text-4xl font-bold text-yellow-600">+173%</div>
              <div className="text-sm text-muted-foreground">F1 Score Gain</div>
            </div>
          </div>

          {/* CTA Button with cute styling */}
          <div className="flex flex-wrap justify-center gap-4">
            <a href="#publications">
              <Button size="lg" className="gap-2 rounded-full px-8 shadow-lg shadow-primary/30 hover:shadow-xl hover:shadow-primary/40 transition-all duration-300">
                <FileText className="h-4 w-4" />
                Read Papers
                <ArrowRight className="h-4 w-4" />
              </Button>
            </a>
          </div>
        </div>

        {/* Affiliation with cute card */}
        <div className="mt-16 text-center">
          <div className="inline-block px-8 py-6 bg-card rounded-3xl border-2 border-primary/10 shadow-xl relative overflow-hidden">
            {/* Decorative elements */}
            <div className="absolute top-0 right-0 w-16 h-16 bg-primary/10 rounded-bl-full -z-0" />
            <div className="absolute bottom-0 left-0 w-12 h-12 bg-secondary/10 rounded-tr-full -z-0" />
            
            <p className="text-sm text-muted-foreground mb-3 relative z-10">A research project from</p>
            
            {/* Lab name highlighted */}
            <div className="relative z-10 mb-3">
              <div className="inline-block px-6 py-2 bg-gradient-to-r from-primary/10 via-orange-500/15 to-amber-400/10 rounded-full border-2 border-primary/30">
                <p className="font-bold text-primary text-lg flex items-center gap-2">
                  <Sparkles className="h-4 w-4 text-amber-500" />
                  Intelligent Software Engineering Laboratory
                  <Sparkles className="h-4 w-4 text-amber-500" />
                </p>
              </div>
            </div>
            
            <p className="font-semibold text-foreground relative z-10">
              Vietnam National University, Hanoi
            </p>
            <p className="text-muted-foreground font-medium relative z-10">
              University of Engineering and Technology
            </p>
            <p className="text-sm text-muted-foreground mt-1 relative z-10">
              Faculty of Information Technology
            </p>
          </div>
        </div>
      </div>
    </section>
  )
}
