import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { ExternalLink, FileText, CheckCircle2, Clock, Sparkles, Star, Rocket, BookOpen } from "lucide-react"
import Link from "next/link"

const publications = [
  {
    status: "published",
    statusLabel: "Published",
    journal: "Knowledge-Based Systems",
    impact: "ISI Q1",
    year: "2025",
    title: "Structured Exploration and Exploitation of Label Functions for Automated Data Annotation",
    authors: [
      "Phong Lam",
      "Ha-Linh Nguyen",
      "Thu-Trang Nguyen",
      "Son Nguyen",
      "Hieu Dinh Vo",
    ],
    description:
      "Empirical findings on automated label function generation, including reliability-diversity trade-offs and a principled approach to LF exploration and exploitation.",
    link: "https://www.sciencedirect.com/science/article/abs/pii/S0950705126005691",
    icon: Star,
    color: "from-amber-400 to-orange-500",
    borderColor: "border-amber-300",
    bgColor: "bg-amber-50",
  },
  {
    status: "published",
    statusLabel: "Published",
    journal: "Future Generation Computer Systems",
    impact: "ISI Q1",
    year: "2025",
    title: "Leveraging Local and Global Relationships for Corrupted Label Detection",
    authors: [
      "Phong Lam",
      "Ha-Linh Nguyen",
      "Xuan-Truc Dao Dang",
      "Van-Son Tran",
      "Minh-Duc Le",
      "Thu-Trang Nguyen",
      "Son Nguyen",
      "Hieu Dinh Vo",
    ],
    description:
      "This work presents comprehensive analyses of corrupted labels and proposes methods to detect and handle label noise using local and global relationships in the data.",
    link: "https://www.sciencedirect.com/science/article/abs/pii/S0167739X2500024X",
    icon: Rocket,
    color: "from-primary to-orange-500",
    borderColor: "border-primary/30",
    bgColor: "bg-primary/5",
  },
  {
    status: "preprint",
    statusLabel: "Preprint",
    journal: "arXiv",
    impact: "Open Access",
    year: "2025",
    title: "Noise-Aware Framework for Correcting Corrupted Labels",
    authors: [
      "Ha-Linh Nguyen",
      "Hong-Anh Nguyen",
      "Minh-Duc La",
      "Phong Lam",
      "Thu-Trang Nguyen",
      "Son Nguyen",
      "Hieu Dinh Vo",
    ],
    description:
      "Evaluation of a noise-aware refinement mechanism for correcting systematically biased weak labels and improving downstream model performance.",
    link: "https://arxiv.org/html/2603.11617v1",
    icon: BookOpen,
    color: "from-orange-400 to-amber-500",
    borderColor: "border-orange-300",
    bgColor: "bg-orange-50",
  },
]

function StatusBadge({ status, label }: { status: string; label: string }) {
  const variants: Record<string, { className: string; icon: typeof CheckCircle2 }> = {
    published: { 
      className: "bg-green-100 text-green-700 border-green-300", 
      icon: CheckCircle2 
    },
    preprint: { 
      className: "bg-blue-100 text-blue-700 border-blue-300", 
      icon: Clock 
    },
  }

  const { className, icon: Icon } = variants[status] || variants.preprint

  return (
    <Badge variant="outline" className={`gap-1.5 rounded-full px-3 py-1 ${className}`}>
      <Icon className="h-3 w-3" />
      {label}
    </Badge>
  )
}

export function PublicationsSection() {
  return (
    <section id="publications" className="py-16 md:py-24 relative overflow-hidden">
      {/* Cute background decorations */}
      <div className="absolute inset-0 -z-10">
        <div className="absolute top-20 left-10 w-3 h-3 bg-primary/30 rounded-full animate-bounce" style={{ animationDelay: '0.5s' }} />
        <div className="absolute bottom-40 right-20 w-4 h-4 bg-secondary/40 rounded-full animate-bounce" style={{ animationDelay: '1s' }} />
        <div className="absolute top-1/2 right-10 w-2 h-2 bg-accent/40 rounded-full animate-bounce" style={{ animationDelay: '1.5s' }} />
      </div>

      <div className="container mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <Badge variant="secondary" className="mb-4 rounded-full px-4 py-1.5 border-2 border-secondary">
            <Sparkles className="h-3.5 w-3.5 mr-1.5" />
            Research Output
            <Sparkles className="h-3.5 w-3.5 ml-1.5" />
          </Badge>
          <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4 text-balance">
            Our Publications
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto text-balance">
            Published in top-tier journals with high impact factor. 
            Click on any paper to read the full article!
          </p>
        </div>

        <div className="grid gap-6 max-w-4xl mx-auto">
          {publications.map((pub, index) => (
            <Link 
              href={pub.link} 
              target="_blank" 
              rel="noopener noreferrer"
              key={index}
              className="group block"
            >
              <Card className={`relative overflow-hidden border-2 ${pub.borderColor} hover:shadow-2xl transition-all duration-500 hover:scale-[1.02] cursor-pointer`}>
                {/* Decorative gradient corner - behind content */}
                <div className={`absolute top-0 right-0 w-32 h-32 bg-gradient-to-br ${pub.color} opacity-10 rounded-bl-full -z-0`} />
                <div className={`absolute bottom-0 left-0 w-20 h-20 ${pub.bgColor} rounded-tr-full -z-0`} />
                
                {/* Cute icon */}
                <div className={`absolute top-4 right-4 w-12 h-12 rounded-2xl bg-gradient-to-br ${pub.color} flex items-center justify-center shadow-lg group-hover:scale-110 transition-transform duration-300 z-10`}>
                  <pub.icon className="h-6 w-6 text-white" />
                </div>

                <CardHeader className="pb-2 pr-20 relative z-10">
                  <div className="flex flex-wrap items-center gap-2 mb-3">
                    <StatusBadge status={pub.status} label={pub.statusLabel} />
                    <Badge variant="secondary" className="rounded-full">
                      {pub.impact}
                    </Badge>
                    <span className="text-sm text-muted-foreground">{pub.year}</span>
                  </div>
                  <h3 className="text-xl font-bold text-foreground leading-tight text-balance group-hover:text-primary transition-colors">
                    {pub.title}
                  </h3>
                  <p className="text-sm font-semibold text-primary mt-1">{pub.journal}</p>
                </CardHeader>
                <CardContent className="relative z-10">
                  <p className="text-sm text-muted-foreground mb-4">{pub.description}</p>
                  <div className="mb-4">
                    <p className="text-xs text-muted-foreground mb-1 font-medium">Authors:</p>
                    <p className="text-sm text-foreground">
                      {pub.authors.map((author, i) => (
                        <span key={i}>
                          {author}
                          {i < pub.authors.length - 1 && ", "}
                        </span>
                      ))}
                    </p>
                  </div>
                  <div className="flex items-center gap-2 text-primary">
                    <span className="text-sm font-medium group-hover:underline">Read Full Paper</span>
                    <ExternalLink className="h-4 w-4 group-hover:translate-x-1 transition-transform" />
                  </div>
                </CardContent>
              </Card>
            </Link>
          ))}
        </div>

        {/* Publication Summary - Cute Style */}
        <div className="mt-12 text-center">
          <div className="inline-flex items-center gap-6 px-8 py-5 bg-card rounded-3xl border-2 border-primary/20 shadow-xl">
            <div className="text-center">
              <div className="text-3xl font-bold text-primary">3</div>
              <div className="text-xs text-muted-foreground font-medium">Total Papers</div>
            </div>
            <div className="h-10 w-0.5 bg-primary/20 rounded-full" />
            <div className="text-center">
              <div className="text-3xl font-bold text-secondary-foreground">2</div>
              <div className="text-xs text-muted-foreground font-medium">Q1 Journals</div>
            </div>
            <div className="h-10 w-0.5 bg-primary/20 rounded-full" />
            <div className="text-center">
              <div className="text-3xl font-bold text-accent-foreground">2</div>
              <div className="text-xs text-muted-foreground font-medium">Published</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
