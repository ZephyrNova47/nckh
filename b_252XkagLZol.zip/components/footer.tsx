import { Heart, Sparkles } from "lucide-react"

export function Footer() {
  return (
    <footer className="border-t-2 border-primary/20 bg-card relative overflow-hidden">
      {/* Cute decorations */}
      <div className="absolute top-0 left-0 w-24 h-24 bg-primary/5 rounded-br-full" />
      <div className="absolute bottom-0 right-0 w-20 h-20 bg-secondary/10 rounded-tl-full" />

      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8 relative">
        <div className="flex flex-col items-center justify-center gap-3 text-center">
          {/* Cute Coca branding */}
          <div className="flex items-center gap-2 mb-2">
            <div className="relative flex h-8 w-8 items-center justify-center rounded-xl bg-gradient-to-br from-primary to-orange-500 text-white font-bold text-sm shadow-lg shadow-primary/30">
              <Sparkles className="absolute -top-1 -right-1 h-3 w-3 text-secondary animate-pulse" />
              C
            </div>
            <span className="font-bold text-lg text-foreground">Coca</span>
          </div>

          <p className="text-sm text-muted-foreground flex items-center gap-1.5">
            Made with <Heart className="h-4 w-4 text-primary fill-primary animate-pulse" /> by Coca Research Team
          </p>
          <p className="text-sm text-muted-foreground">
            Vietnam National University, Hanoi - University of Engineering and Technology
          </p>
          <p className="text-sm text-muted-foreground font-medium bg-gradient-to-r from-primary/10 via-secondary/20 to-primary/10 px-4 py-1.5 rounded-full">
            Faculty of IT - iSE Lab
          </p>
        </div>
      </div>
    </footer>
  )
}
