import { HeroSection } from "@/components/hero-section"
import { PublicationsSection } from "@/components/publications-section"
import { KeyResultsSection } from "@/components/key-results-section"
import { MethodologySection } from "@/components/methodology-section"
import { TeamSection } from "@/components/team-section"
import { Footer } from "@/components/footer"
import { Navigation } from "@/components/navigation"

export default function Home() {
  return (
    <main className="min-h-screen bg-background">
      <Navigation />
      <HeroSection />
      <PublicationsSection />
      <KeyResultsSection />
      <MethodologySection />
      <TeamSection />
      <Footer />
    </main>
  )
}
